package com.tictactoe.flutter_tic_tac_toe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
